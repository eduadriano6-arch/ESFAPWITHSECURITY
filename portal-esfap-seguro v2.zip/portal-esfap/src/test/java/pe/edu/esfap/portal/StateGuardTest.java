package pe.edu.esfap.portal;

import static org.junit.jupiter.api.Assertions.*;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;

class StateGuardTest {
    static final ObjectMapper OM = new ObjectMapper();
    static JsonNode j(String s) { try { return OM.readTree(s); } catch (Exception e) { throw new RuntimeException(e); } }

    @Test void estudianteNoVeNiEscribeClavesDeOtrosRoles() {
        var all = j("{\"roster\":[1],\"backups\":[\"x\"],\"mat\":{\"status\":null},\"pays\":[]}");
        var v = StateGuard.readView("est", "E1", all);
        assertFalse(v.has("roster")); assertFalse(v.has("backups")); assertTrue(v.has("mat"));
        var m = StateGuard.mergeWrite("est", "E1", all, j("{\"roster\":[9],\"backups\":[\"hack\"]}"));
        assertEquals(1, m.get("roster").size()); assertEquals("x", m.get("backups").get(0).asText());
    }
    @Test void estudianteVeSoloSusTramites() {
        var all = j("{\"tram\":[{\"t\":\"A\",\"est\":\"E1\"},{\"t\":\"B\",\"est\":\"E2\"}]}");
        var v = StateGuard.readView("est", "E1", all);
        assertEquals(1, v.get("tram").size());
        assertEquals("A", v.get("tram").get(0).get("t").asText());
    }
    @Test void estudianteNoPuedeEmitirTramitesNiPonerCodigo() {
        var cur = j("{\"tram\":[{\"t\":\"Constancia de estudios\",\"est\":\"E1\",\"st\":\"En proceso\",\"datos\":{}},{\"t\":\"Certificado de notas\",\"est\":\"E2\",\"st\":\"En proceso\"}]}");
        var inc = j("{\"tram\":[{\"t\":\"Constancia de estudios\",\"est\":\"E1\",\"st\":\"Emitido\",\"code\":\"ESFAP-AAAAAA\"},"
            + "{\"t\":\"Récord académico\",\"est\":\"E1\",\"st\":\"Emitido\",\"code\":\"ESFAP-BBBBBB\"},{\"t\":\"Falso\",\"est\":\"E1\"}]}");
        var m = StateGuard.mergeWrite("est", "E1", cur, inc);
        var tr = m.get("tram");
        assertEquals(3, tr.size()); // 1 ajeno + 1 propio existente + 1 nuevo válido
        for (JsonNode t : tr) { assertNotEquals("Emitido", t.path("st").asText()); assertTrue(t.path("code").isMissingNode()); }
    }
    @Test void estudianteNoPuedeAprobarSuMatricula() {
        var m = StateGuard.mergeWrite("est", "E1", j("{}"), j("{\"mat\":{\"status\":\"Aprobada\",\"courses\":[\"DIB1\",\"hack\"]}}"));
        assertEquals("Pendiente", m.get("mat").get("status").asText());
        assertEquals(1, m.get("mat").get("courses").size());
        var m2 = StateGuard.mergeWrite("est", "E1", m, j("{\"mat\":{\"status\":\"Aprobada\",\"courses\":[\"PIN1\"]}}"));
        assertEquals("Pendiente", m2.get("mat").get("status").asText());
    }
    @Test void estudianteNoPuedeCambiarImportesNiRegalarPagos() {
        var inc = j("{\"pays\":[{\"id\":1,\"m\":1},{\"id\":2,\"c\":\"X\",\"m\":1,\"st\":\"Pagado\",\"rec\":\"R-0102\"},{\"id\":3,\"st\":\"Pagado\",\"rec\":\"malo\"},{\"id\":99,\"st\":\"Pagado\"}]}");
        var p = StateGuard.mergeWrite("est", "E1", j("{}"), inc).get("pays");
        assertEquals(3, p.size());
        assertEquals(120, p.get(0).get("m").asInt());
        assertEquals("Pagado", p.get(1).get("st").asText()); assertEquals(80, p.get(1).get("m").asInt()); assertEquals("Pensión octubre", p.get(1).get("c").asText());
        assertEquals("Pendiente", p.get(2).get("st").asText());
    }
    @Test void rechazaHtmlEnCualquierTexto() {
        assertThrows(IllegalArgumentException.class, () -> StateGuard.mergeWrite("doc", "d", j("{}"), j("{\"mats\":[{\"t\":\"<img src=x onerror=alert(1)>\"}]}")));
    }
    @Test void soloAceptaPdfReales() {
        assertThrows(IllegalArgumentException.class, () -> StateGuard.mergeWrite("doc", "d", j("{}"), j("{\"libFiles\":[{\"data\":\"data:text/html;base64,PHNjcmlwdD4=\"}]}")));
        assertDoesNotThrow(() -> StateGuard.mergeWrite("doc", "d", j("{}"), j("{\"libFiles\":[{\"data\":\"data:application/pdf;base64,JVBERi0xLjQK\"}]}")));
    }
    @Test void rolSinPermisoNoEscribeNada() {
        var m = StateGuard.mergeWrite("ti", "t", j("{\"grades\":{\"A\":[1]}}"), j("{\"grades\":{\"A\":[20]}}"));
        assertEquals(1, m.get("grades").get("A").get(0).asInt());
    }
    @Test void eliminaLogsDelCliente() {
        var m = StateGuard.mergeWrite("adm", "a", j("{\"logs\":[\"x\"]}"), j("{\"mat\":{\"status\":null,\"courses\":[]}}"));
        assertFalse(m.has("logs"));
    }
}
