package pe.edu.esfap.portal;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

class CryptoTest {
    @Test void cifraYDescifra() {
        Crypto.setKey(new byte[32]);
        String c = Crypto.encrypt("{\"mat\":\"datos personales\"}");
        assertTrue(c.startsWith("v1:"));
        assertFalse(c.contains("datos personales"));
        assertEquals("{\"mat\":\"datos personales\"}", Crypto.decrypt(c));
    }
    @Test void cadaCifradoUsaUnIvDistinto() {
        Crypto.setKey(new byte[32]);
        assertNotEquals(Crypto.encrypt("igual"), Crypto.encrypt("igual"));
    }
    @Test void detectaManipulacion() {
        Crypto.setKey(new byte[32]);
        String c = Crypto.encrypt("texto");
        char last = c.charAt(c.length() - 5);
        String alterado = c.substring(0, c.length() - 5) + (last == 'A' ? 'B' : 'A') + c.substring(c.length() - 4);
        assertThrows(IllegalStateException.class, () -> Crypto.decrypt(alterado));
    }
    @Test void aceptaTextoHeredadoSinCifrar() { assertEquals("texto plano antiguo", Crypto.decrypt("texto plano antiguo")); assertNull(Crypto.decrypt(null)); }
}
