package pe.edu.esfap.portal;

import static org.hamcrest.Matchers.containsString;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;

@SpringBootTest
@AutoConfigureMockMvc
class PortalApplicationTests {
    @Autowired MockMvc mvc;

    @Test void contextLoads() {}

    @Test void portadaSeSirve() throws Exception {
        mvc.perform(get("/index.html")).andExpect(status().isOk())
           .andExpect(content().string(org.hamcrest.Matchers.containsString("Felipe Guamán Poma de Ayala")));
    }

    @Test void postSinTokenCsrfEsRechazado() throws Exception {
        mvc.perform(post("/api/login").contentType("application/json").content("{\"id\":\"x\",\"pw\":\"y\"}")).andExpect(status().isForbidden());
    }

    @Test void datosPrivadosExigenSesion() throws Exception {
        mvc.perform(get("/api/state")).andExpect(status().isUnauthorized());
        mvc.perform(get("/api/users")).andExpect(status().isForbidden());
        mvc.perform(get("/api/me")).andExpect(status().isUnauthorized());
    }

    @Test void tokenCsrfSeEntregaPorEndpoint() throws Exception {
        mvc.perform(get("/api/csrf")).andExpect(status().isOk()).andExpect(jsonPath("$.token").isNotEmpty());
    }

    @Test void cabecerasDeSeguridad() throws Exception {
        mvc.perform(get("/index.html")).andExpect(status().isOk())
           .andExpect(header().string("Content-Security-Policy", containsString("script-src 'self'")))
           .andExpect(header().string("X-Frame-Options", "DENY"))
           .andExpect(header().string("Referrer-Policy", "no-referrer"))
           .andExpect(header().string("X-Content-Type-Options", "nosniff"))
           .andExpect(header().exists("Permissions-Policy"));
    }

    @Test void codigoDeVerificacionInvalidoSeRechaza() throws Exception {
        mvc.perform(get("/api/verify/{c}", "abc' OR 1=1")).andExpect(jsonPath("$.valid").value(false));
    }
}
