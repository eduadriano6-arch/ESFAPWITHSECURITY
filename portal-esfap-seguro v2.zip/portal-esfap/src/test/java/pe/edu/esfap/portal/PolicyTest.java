package pe.edu.esfap.portal;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

class PolicyTest {
    @Test void bloqueoTrasTresIntentos() { assertFalse(Policy.locked(2)); assertTrue(Policy.locked(3)); }
    @Test void contrasenaFuerte() {
        assertTrue(Policy.strongPassword("Estud-2026-Seguro"));
        assertFalse(Policy.strongPassword("Estud2026"));          // corta y sin símbolo
        assertFalse(Policy.strongPassword("corta1!A"));
        assertFalse(Policy.strongPassword("sololetrasMayusYMinus"));
        assertFalse(Policy.strongPassword("todominusculas-123456"));
        assertFalse(Policy.strongPassword("Password-123456"));     // palabra común
        assertFalse(Policy.strongPassword(null));
    }
    @Test void contrasenaNoContieneUsuario() {
        assertFalse(Policy.strongPassword("Lucia-Secreta-2026!", "lucia"));
        assertTrue(Policy.strongPassword("Cuaderno-Azul-2026!", "lucia"));
    }
    @Test void roles() { assertTrue(Policy.canViewLogs("ti")); assertFalse(Policy.canViewLogs("est")); assertTrue(Policy.validRole("doc")); assertFalse(Policy.validRole("root")); assertFalse(Policy.canManageUsers("doc")); }
    @Test void sinEscaladaDePrivilegios() {
        assertTrue(Policy.canAssignRole("ti", "adm"));
        assertTrue(Policy.canAssignRole("adm", "est"));
        assertFalse(Policy.canAssignRole("adm", "ti"));
        assertFalse(Policy.canAssignRole("adm", "adm"));
        assertFalse(Policy.canAssignRole("doc", "est"));
    }
    @Test void nombresDeUsuario() { assertTrue(Policy.validUsername("E2024001")); assertFalse(Policy.validUsername("a'b")); assertFalse(Policy.validUsername("ab")); }
    @Test void contrasenasAleatoriasCumplenLaPolitica() { for (int i = 0; i < 20; i++) assertTrue(Policy.strongPassword(DataSeeder.randomPassword("soporte"), "soporte")); }
}
